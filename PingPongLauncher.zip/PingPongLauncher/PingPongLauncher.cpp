#include "PingPongLauncher.h"

// Must match the board firmware's protocol defines exactly.
static const uint8_t FRAME_SYNC       = 0xAA;
static const uint8_t CMD_STOP_MOTORS  = 0x01;
static const uint8_t CMD_START_MOTORS = 0x02;
static const uint8_t CMD_FIRE         = 0x03;

PingPongLauncher::PingPongLauncher(Stream &serial) : _serial(serial) {}

void PingPongLauncher::sendFrame(uint8_t cmd, const uint8_t *params, uint8_t paramLen) {
  _serial.write(FRAME_SYNC);
  _serial.write(cmd);
  if (params != nullptr && paramLen > 0) {
    _serial.write(params, paramLen);
  }
}

void PingPongLauncher::stopMotors() {
  sendFrame(CMD_STOP_MOTORS, nullptr, 0);
}

void PingPongLauncher::startMotors(uint8_t speed) {
  // Frame is 3 bytes (sync, cmd, speed).
  sendFrame(CMD_START_MOTORS, &speed, 1);
}

void PingPongLauncher::fire() {
  sendFrame(CMD_FIRE, nullptr, 0);
}
