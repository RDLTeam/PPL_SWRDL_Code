/*
  BasicControl.ino

  Demonstrates controlling the ping-pong ball launcher PCB from an
  Arduino, passing in whichever serial interface is wired to the
  board's UART connection.

  This example uses Serial1 (a second hardware UART), which is
  available on boards like the Arduino Mega, Leonardo, Due, or an
  ESP32/ESP8266. If your board only has one hardware UART, see the
  SoftwareSerial note below.
*/

#include <PingPongLauncher.h>

// Pass whichever Stream-compatible serial port is wired to the
// launcher board's RX/TX pins. Any of the following work:
//
//   PingPongLauncher launcher(Serial1);      // second hardware UART
//   PingPongLauncher launcher(Serial);       // primary UART (careful:
//                                             // shared with USB on some boards)
//
// Or, on boards with only one hardware UART, use SoftwareSerial:
//
//   #include <SoftwareSerial.h>
//   SoftwareSerial mySerial(10, 11); // RX, TX
//   PingPongLauncher launcher(mySerial);

PingPongLauncher launcher(Serial1);

void setup() {
  Serial.begin(115200);      // USB debug console
  Serial1.begin(115200);     // must match the board firmware's baud rate

  Serial.println("Ping pong launcher ready.");

  // Make sure motors are stopped before doing anything else.
  launcher.stopMotors();
}

void loop() {
  // Spin up the motors at roughly half speed.
  Serial.println("Starting motors...");
  launcher.startMotors(128);
  delay(2000);

  // Fire one ball. The board handles the open/close timing on its own.
  Serial.println("Firing...");
  launcher.fire();
  delay(1500); // give the servo time to cycle before firing again

  // Stop the motors.
  Serial.println("Stopping motors.");
  launcher.stopMotors();
  delay(3000);
}
