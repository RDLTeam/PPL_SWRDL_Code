/*
  PingPongLauncher.h

  Arduino host-side library for the ping-pong ball launcher PCB
  (a motor + servo controller running the FRAME_SYNC UART protocol).

  Wire format sent to the board:
    [ 0xAA (sync) ][ cmd ][ optional params... ]

    STOP_MOTORS  (0x01) : 2 bytes  -> 0xAA, 0x01
    START_MOTORS (0x02) : 3 bytes  -> 0xAA, 0x02, speed
    FIRE         (0x03) : 2 bytes  -> 0xAA, 0x03

  speed is applied to both motors.

  Works with any Stream-based serial interface: HardwareSerial,
  SoftwareSerial, USBSerial, etc. Pass the interface you want to use
  into the constructor.
*/

#ifndef PING_PONG_LAUNCHER_H
#define PING_PONG_LAUNCHER_H

#include <Arduino.h>

class PingPongLauncher {
  public:
    // Pass any Stream (e.g. Serial, Serial1, a SoftwareSerial instance...).
    // The caller is responsible for calling .begin(115200) on that
    // interface before use (115200 8N1 is what the board's firmware
    // expects).
    explicit PingPongLauncher(Stream &serial);

    // Stops both drive motors (speed = 0).
    void stopMotors();

    // Starts both drive motors at the given speed, 0-255.
    // Note: the UART frame carries speed as a single unsigned byte, so
    // only forward speed can be commanded over serial (the firmware's
    // signed/reverse logic, if any, is only reachable internally, not
    // via this protocol).
    void startMotors(uint8_t speed);

    // Triggers a single shot: opens the feed servo, holds it open
    // for ~1 second (handled on-board), then closes it automatically.
    void fire();

  private:
    Stream &_serial;

    void sendFrame(uint8_t cmd, const uint8_t *params, uint8_t paramLen);
};

#endif // PING_PONG_LAUNCHER_H
